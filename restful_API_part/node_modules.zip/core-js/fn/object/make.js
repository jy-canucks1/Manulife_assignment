require('../../modules/core.object.make');
module.exports = require('../../modules/_core').Object.make;
