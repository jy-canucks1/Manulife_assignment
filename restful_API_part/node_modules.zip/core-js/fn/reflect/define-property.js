require('../../modules/es6.reflect.define-property');
module.exports = require('../../modules/_core').Reflect.defineProperty;
