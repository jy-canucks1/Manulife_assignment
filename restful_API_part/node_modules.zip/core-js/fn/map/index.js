require('../../modules/es6.object.to-string');
require('../../modules/es6.string.iterator');
require('../../modules/web.dom.iterable');
require('../../modules/es6.map');
require('../../modules/es7.map.to-json');
require('../../modules/es7.map.of');
require('../../modules/es7.map.from');
module.exports = require('../../modules/_core').Map;
