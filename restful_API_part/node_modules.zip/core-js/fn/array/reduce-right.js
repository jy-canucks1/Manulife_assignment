require('../../modules/es6.array.reduce-right');
module.exports = require('../../modules/_core').Array.reduceRight;
