require('../../modules/es6.array.for-each');
module.exports = require('../../modules/_core').Array.forEach;
