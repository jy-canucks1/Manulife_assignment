require('../../modules/es6.string.starts-with');
module.exports = require('../../modules/_core').String.startsWith;
