require('../../../modules/es7.string.at');
module.exports = require('../../../modules/_entry-virtual')('String').at;
